
function startRetroactive() {
    logMessage("🔁 Retroactive Recording started...");
}
function startTimeTravel() {
    logMessage("🕒 Time Travel initiated...");
}
function submitGoal() {
    const goalInput = document.getElementById("inventionGoal");
    const goal = goalInput.value.trim();
    if (goal) {
        logMessage("🛠️ Inventing: " + goal);
        goalInput.value = "";
    }
}
function logMessage(message) {
    const logList = document.getElementById("logList");
    const item = document.createElement("li");
    item.textContent = message;
    logList.appendChild(item);
}
